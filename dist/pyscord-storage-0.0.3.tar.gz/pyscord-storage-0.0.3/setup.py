from setuptools import setup

setup(install_requires=["requests>=2.25.1"])
